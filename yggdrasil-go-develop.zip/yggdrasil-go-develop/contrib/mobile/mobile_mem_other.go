//go:build !go1.20
// +build !go1.20

package mobile

func setMemLimitIfPossible() {
	// not supported by this Go version
}
